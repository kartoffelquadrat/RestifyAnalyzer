package eu.kartoffelquadrat.xoxinternals;

import org.junit.Test;

public class DesktopLauncherTest {

    @Test
    public void testMain() {
        DesktopLauncher.main(new String[]{});
    }

}
