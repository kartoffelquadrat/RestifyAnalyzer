package eu.kartoffelquadrat.xoxinternals.controller;

import eu.kartoffelquadrat.xoxinternals.model.Board;
import eu.kartoffelquadrat.xoxinternals.model.BoardReadOnly;
import eu.kartoffelquadrat.xoxinternals.model.Player;
import eu.kartoffelquadrat.xoxinternals.model.XoxInitSettings;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("xox")
public class XoxController {
    @GetMapping()
    public Collection<Long> getGames() {
        return XoxManagerImpl.getInstance().getGames();
    }

    @PostMapping()
    public Long addGame(@RequestBody XoxInitSettings settings) {
        return XoxManagerImpl.getInstance().addGame(settings);
    }

    @GetMapping("{id}")
    public Ranking getGame(@PathVariable("id") Long id) {
        return XoxManagerImpl.getInstance().getRanking(id);
    }

    @DeleteMapping("{id}")
    public void deleteGame(@PathVariable("id") Long id) {
        XoxManagerImpl.getInstance().removeGame(id);
    }

    @GetMapping("{id}/players")
    public Player[] getPlayers(@PathVariable("id") Long id) {
        return XoxManagerImpl.getInstance().getPlayers(id);
    }

    @GetMapping("{id}/players/{playerName}/actions")
    public XoxClaimFieldAction[] getActionsForPlayer(@PathVariable("id") Long id,
                                                     @PathVariable("playerName") String playerName) {
        return XoxManagerImpl.getInstance().getActions(id, playerName);
    }

    @PostMapping("{id}/players/{playerName}/actions/{actionIndex}")
    public void performAction(@PathVariable("id") Long id,
                              @PathVariable("playerName") String playerName,
                              @PathVariable("actionIndex") int actionIndex) {
        XoxManagerImpl.getInstance().performAction(id, playerName, actionIndex);
    }

    @GetMapping("{id}/board")
    public BoardReadOnly getBoard(@PathVariable() Long id) {
        return XoxManagerImpl.getInstance().getBoard(id);
    }
}
