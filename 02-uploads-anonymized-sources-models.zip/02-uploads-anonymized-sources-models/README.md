# This is the original uploads collection

## Contents

For each participant:

 * Comments.txt
 * Manual task code
 * TouchCORE project with generated maven sources

## Modification

 * Target folders and videos have been deleted.
 * All Manual project files except src and pom.xml have been deleted. This includes deletion of ide meta files and git files.
 * pom.xmls have been scanned for plain participant names and changed to pseudonyms.

## Comments

Can be safely published.

 * Some submissions do not compile or run: missing poms, incorrect launcher references in poms.
