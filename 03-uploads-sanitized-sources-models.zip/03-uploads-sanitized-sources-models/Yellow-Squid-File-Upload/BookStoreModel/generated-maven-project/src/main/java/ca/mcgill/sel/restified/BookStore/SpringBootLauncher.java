package ca.mcgill.sel.restified.BookStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLauncher {
    
    public static void main(String[] args) {
        SpringApplication.run(SpringBootLauncher.class, args);
    }
}
